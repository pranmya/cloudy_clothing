function addToCart() {
    alert('Product added to cart!');
    // You can add logic to handle cart functionality or backend interaction here
}
