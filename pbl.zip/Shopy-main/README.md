# Responsive Clothing Website

Build a Clothing Website using **HTML**, **CSS** & **JavaScript**.

[Watch video on youtube](https://youtu.be/l_pICfsY3KM "Responsive Clothing Website")

[View demo](https://codingweb33.github.io/Shopy/ "Responsive Clothing Website")

Video contents:

* Modern Design
* Responsive Design for mobile devices
* Navbar menu indicator
* Fetch products from API
* Used Scroll Reveal JS
* Used Swiper JS

![img](Clothing%20Website.png)

Hey bro please don't forget to subscribe to [my channel](https://www.youtube.com/@CodingWeb3 "CodingWeb") and like the [video](https://youtu.be/l_pICfsY3KM "Responsive Clothing Website") 😊😊.